const cmd_termux = (prefix) => {
return `
 nada por aqui 🎈
`
}

exports.cmd_termux = cmd_termux
