const menuadulto = (prefix) => {
return`

┌═══════════════
║     🔞 •Conteúdo +18• 🔞
║ Necessita do nsfw ativado
╚─══════════════
┌═══════════════
║🔞➢ ${prefix}xnxx
║🔞➢ ${prefix}xnxxilink 
║🔞➢ ${prefix}spankgang 
║🔞➢ ${prefix}hentai 
║🔞➢ ${prefix}hentai2 
║🔞➢ ${prefix}loli 
║🔞➢ ${prefix}loli2 
║🔞➢ ${prefix}neko 
║🔞➢ ${prefix}ahegao 
║🔞➢ ${prefix}ass 
║🔞➢ ${prefix}bdsm 
║🔞➢ ${prefix}blowjob 
║🔞➢ ${prefix}cuckold 
║🔞➢ ${prefix}cum 
║🔞➢ ${prefix}ero 
║🔞➢ ${prefix}femdom 
║🔞➢ ${prefix}foot 
║🔞➢ ${prefix}gangbang  
║🔞➢ ${prefix}glasses  
║🔞➢ ${prefix}jahy  
║🔞➢ ${prefix}manga  
║🔞➢ ${prefix}masturb  
║🔞➢ ${prefix}quadrinhos18  
║🔞➢ ${prefix}plaq  
║🔞➢ ${prefix}plaq1  
║🔞➢ ${prefix}plaq2  
║🔞➢ ${prefix}plaq3  
║🔞➢ ${prefix}plaq4  
║🔞➢ ${prefix}plaq5  
║🔞➢ ${prefix}placaloli  
╚══════════════➤
*BOT:*  ${NomeDoBot}🔥

`
}
exports.menuadulto = menuadulto